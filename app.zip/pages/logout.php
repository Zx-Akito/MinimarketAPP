<?php
    $template = "dashboard";
    $judul    = "Bye bye";

    $_SESSION['JenisLog']="";
    $_SESSION['Id']="";
    header("location:index.php");

?>