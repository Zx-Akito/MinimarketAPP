<?php
    $y=date("Y");
    $footer="
        <div class='text-center'>
            <p>Copyright &copy; ZxAkito $y</p>
        </div>
    ";

?>