<?php
    $menusidebar = "

        <!-- Nav Item - Dashboard -->
        <li class='nav-item $active1'>
            <a class='nav-link' href='index.php'>
            <i class='fas fa-home'></i>
            <span>Beranda</span>
            </a>
        </li>
        
        <!-- Nav Item - Pages Collapse Menu -->
        <li class='nav-item $active5'>
            <a class='nav-link' href='?page=kasir/penjualan'>
            <i class='fa-solid fa-cart-shopping'></i>
                <span>Penjualan</span>
            </a>
        </li>

    ";
?>