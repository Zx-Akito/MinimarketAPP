<?php
    $menusidebar = "

        <!-- Nav Item - Dashboard -->
        <li class='nav-item $active1'>
            <a class='nav-link' href='index.php'>
            <i class='fas fa-home'></i>
            <span>Beranda</span>
            </a>
        </li>
        
        <!-- Nav Item - Pages Collapse Menu -->
        <li class='nav-item $active2'>
            <a class='nav-link' href='?page=gudang/barang'>
            <i class='fa-solid fa-box-open'></i>
                <span>Barang</span>
            </a>
        </li>

        <li class='nav-item $active3'>
            <a class='nav-link' href='?page=gudang/supplier'>
            <i class='fa-solid fa-cart-shopping'></i>
                <span>Supplier</span>
            </a>
        </li>

        <li class='nav-item $active4'>
            <a class='nav-link' href='?page=gudang/pembelian'>
            <i class='fa-solid fa-bag-shopping'></i>
                <span>Pembelian</span>
            </a>
        </li>
    ";
?>