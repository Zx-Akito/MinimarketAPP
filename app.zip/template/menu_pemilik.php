<?php
    $menusidebar = "

        <!-- Nav Item - Dashboard -->
        <li class='nav-item $active1'>
            <a class='nav-link' href='index.php'>
            <i class='fas fa-home'></i>
            <span>Beranda</span>
            </a>
        </li>
        
        <!-- Nav Item - Pages Collapse Menu -->
        <li class='nav-item $active2'>
            <a class='nav-link' href='?page=pemilik/pengguna'>
            <i class='fas fa-user-plus'></i>
                <span>Pengguna</span>
            </a>
        </li>

        <li class='nav-item $active3'>
            <a class='nav-link' href='?page=pemilik/laporan_pembelian'>
            <i class='fas fa-file-lines'></i>
                <span>Laporan Pembelian</span>
            </a>
        </li>

        <li class='nav-item $active4'>
            <a class='nav-link' href='?page=pemilik/laporan_penjualan'>
            <i class='fa-solid fa-file-invoice-dollar'></i>
                <span>Laporan Penjualan</span>
            </a>
        </li>

    ";
?>