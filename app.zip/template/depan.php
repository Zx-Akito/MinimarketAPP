<?php
    echo"
        <!DOCTYPE html>
        <html>
            <head>
            <meta charset='UTF-8'>
            <meta http-equiv='X-UA-Compatible' content='IE=edge'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <title>$judul</title>
            <link rel='shortcut icon' href='./assets/img/logo.png'/>
            <!-- CSS | Bootstrap -->
            <link rel='stylesheet' href='./assets/css/login.css??'>
            <link rel='stylesheet' href='./assets/vendor/bootstrap/css/bootstrap.css'>
            <!-- Fonts -->
            <link rel='preconnect' href='https://fonts.googleapis.com'>
            <link rel='preconnect' href='https://fonts.gstatic.com' crossorigin>
            <link href='https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@300;600&display=swap' rel='stylesheet'>
            <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css'/>
            </head>
            <body>
                $konten
                <script src='./assets/vendor/bootstrap/js/bootstrap.js'></script>
                <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
                $alert
            </body>
        </html>
    ";
?>