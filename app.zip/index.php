<?php
    error_reporting(0);
    session_start();
    
    include ("app/db.php"); // Koneksi Database
    include ("app/function.php"); // Fungsi
    include ("app/routing.php"); // Penghubung Halaman
?>